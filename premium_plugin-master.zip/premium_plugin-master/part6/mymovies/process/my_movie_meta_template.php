<ul class="movie_list_meta">
	<li><strong>Director : </strong>DIRECTOR_PH</li>
	<li><strong>Writer : </strong>WRITER_PH</li>
	<li><strong>Stars : </strong>STARS_PH</li>
	<li><strong>Genre : </strong>GENRE_PH</li>
	<li><strong>Runtime : </strong>RUNTIME_PH</li>
</ul>