<?php 

/*  @PACKAGE MYMOVIES
* 	USE: All widget intilize by this function.
*	DESCRIPTION: All widget intilize by this function.
*/

function sm_widgets_init(){
	register_widget( 'SM_motd_widget' );
}

