<?php 
/*  @PACKAGE MYMOVIES
* 	USE: use form corn job.
*	DESCRIPTION: create daily movie randomly.
*/

function sm_create_daily_movie(){
	
}