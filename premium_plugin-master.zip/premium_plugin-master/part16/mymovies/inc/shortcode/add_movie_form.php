<div class="movie_status"></div>
<form action="" id="add_new_movie">
	<div class="form-group">
		<label for="">Title</label>
		<input id="sm__title" class="form-control" type="text" />
	</div>
	SM_CONTENT_EDITOR
	<div class="form-group">
		<label for="">Director</label>
		<input id="sm__director" class="form-control" type="text" />
	</div>
	<div class="form-group">
		<label for="">Writer</label>
		<input id="sm__writer" class="form-control" type="text" />
	</div>
	<div class="form-group">
		<label for="">Stars</label>
		<input id="sm__stars" class="form-control" type="text" />
	</div>
	<div class="form-group">
		<label for="">Genre</label>
		<select name="" id="sm__genre" class="form-control">
			<option value="comedy">Comedy</option>
			<option value="action">Action</option>
			<option value="thillers">Thillers</option>
			<option value="others">Others</option>
		</select>
	</div>
	<div class="form-group">
		<label for="">Run Time</label>
		<input id="sm__run_time" class="form-control" type="text" />
	</div>
	<div class="form-group">
		
		<button class="btn btn-primary">Sumbit Movie</button>
	</div>
</form>