<?php 



/*  @PACKAGE MYMOVIES
* 	USE: create metabox.
*	DESCRIPTION: 1. create metabox on my_movie post type only.
*/

function my_movie_meta_callback(){
	echo 'scbsdcvdbsv';
}