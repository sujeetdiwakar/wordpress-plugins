<ul class="movie_list_meta">
	<li><strong>Director : </strong>DIRECTOR_PH</li>
	<li><strong>Writer : </strong>WRITER_PH</li>
	<li><strong>Stars : </strong>STARS_PH</li>
	<li><strong>Genre : </strong>GENRE_PH</li>
	<li><strong>Runtime : </strong>RUNTIME_PH</li>
	<li><strong>Rating : </strong>
		<div READONLY_PLACEHOLDER  data-rateit-resetable="false" data-rateit-max="10" data-smid="MOVIE_ID" data-rateit-value="RATING_VALUE" id="sm_movie_rating" class="rateit"></div>
	
	</li>
</ul>